//
//  ViewController.swift
//  Calculator
//
//  Created by Student on 07/03/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var resultLabel: UILabel!
    

    @IBOutlet weak var textField1: UITextField!
    
    @IBOutlet weak var textField2: UITextField!
    
    
    
    
    @IBAction func add(_ sender: Any) {
        let num1: Int! = Int(textField1.text!)
        let num2: Int! = Int(textField2.text!)
        
        let sum = num1 + num2
        resultLabel.text = String(sum)
    }
    
    
    @IBAction func sub(_ sender: Any) {
        let num1: Int! = Int(textField1.text!)
        let num2: Int! = Int(textField2.text!)
        
        let sub1 = num1 - num2
        resultLabel.text = String(sub1)
        
        
    }
    
        
    @IBAction func mul(_ sender: Any) {
        let num1: Int! = Int(textField1.text!)
        let num2: Int! = Int(textField2.text!)
        
        let Mul = num1 * num2
        resultLabel.text = String(Mul)
        print(Mul)
    }
    
    
    @IBAction func div(_ sender: Any) {
        let num1: Int! = Int(textField1.text!)
        let num2: Int! = Int(textField2.text!)
        
        if(num2 == 0){
            resultLabel.text = "Do not enter 0"
        } else {
            
            let Div = num1 + num2
            resultLabel.text = String(Div)
        }
    }
    
}

